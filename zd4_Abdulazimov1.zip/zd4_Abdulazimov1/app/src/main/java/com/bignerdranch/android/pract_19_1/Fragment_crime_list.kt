package com.bignerdranch.android.pract_19_1


import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class Fragment_crime_list : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.fragment_crime_list)
    }
}

